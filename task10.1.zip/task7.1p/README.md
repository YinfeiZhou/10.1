# Install Dependencies
```sh
# install front dependencies
yarn 
# intsall bakend dependencies
cd bakend && yarn 
```

# Run Project
```sh
yarn start # start front
yarn serve  # start backend
```
# build Project

```
yarn build
```